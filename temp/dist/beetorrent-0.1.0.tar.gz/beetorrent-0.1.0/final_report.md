Final project for CMSC417 implementing a BitTorrent client.

Project begun on GitHub. Request access to https://github.com/SabineMay/cmsc417-BitTorrent/ if interested.

# 0. Quick start
## Environment setup and takedown
The command-line input we provide here is Mac-specific, but this project should be runnable on Windows and Linux as well
1. Install Python version 3.12 (https://www.python.org/downloads/)
2. Download the wheel file at dist/BeeTorrent-0.1.0-py3-none-any.whl in this repo
3. Create a personal Python venv 
    >```python3 -m venv <venv_name>```
4. Activate <venv_name>
    > ```source <venv_name>/bin/activate```
5. Install the BeeTorrent package into your venv. 
    > ```pip install <local_path>/dist/BeeTorrent-0.1.0-py3-none-any```
6. Do cool torrent-y things
7. Uninstall BeeTorrent if you didn't like it.
    > ```pip uninstall BeeTorrent```
7. Deactivate <venv_name>
    > ```deactivate```

## Starting a torrent
If you've cloned this repo (instead of using the wheel distirubion file), run ```python3 driver.py -f <relative_path_to_torrent_file> -p <desired_port_number>```

If you've installed the package via the distribution file, run ```Dance -f <relative_path_to_torrent_file> -p <desired_port_number>```

Note that -p is optional in both instances. 

BeeTorrent will create two directories, if they don't already exist, wherever you start your torrent: 
1. tor-file-outputs: stores all output files from the torrent 
2. logs: stores automatically generated .log files detailing the peers (Bees) that yo've connected to in the swarm

# 1. Supported features
Protocol spec: https://wiki.theory.org/BitTorrentSpecification

## Basic features
* Requests-less communication with HTTP tracker 
* Handshaking with peers
* Support for peer messages with id $\in$ [0, 1, 2, 3, 4, 6, 7, 8] 
    * keep-alive
    * choke
    * unchoke
    * interested
    * not interested
    * have
    * request
    * piece
    * cancel

## \~Fancy\~ features
* Communication with UDP tracker 
* Communication with HTTPS tracker
* Rarest-first download strategy
* Support for multi-file torrents
* Support for peer messages with id $\in$ [5]
    * bitfield

# 2. Design choices

## High-level decisions
* We wanted to minimize the number of file I/O operations (which slow down our program), while implementing the rarest-first download strategy and maintaining functionality for large torrent files. We decided to institute a maximum number of incomplete pieces that our client can store in RAM. Until that maximum has been reached, our client chooses a rare piece from which to send out a block request. Once that maximum has been reached, our client only sends out requests for the in-progress pieces (until they are completed, at which point we return to rarest-first). The hope is that the client will finish pieces quickly, instead of having a block or two for many incomplete pieces. This provides two benefits: 
1. The client will have more data to upload to peers, leading to more unchokes.
2. The client can wait to write to disk until all the blocks for a piece have come in and can be hash-verified—-if this maximum was not implemented, some other strategy would have to be devised to ensure that a client never overuses its RAM by keeping too many unverified blocks in memory. A large torrent file and bad luck could otherwise crash the program.

    See https://stackoverflow.com/questions/58041609/bittorent-rarest-first-algorithm-how-are-pieces-selected.

* We wanted to make sure that if multiple of our clients were downloading the same torrent, they wouldn't be requesting the same rarest pieces. Per the wikitheory spec: “Note that any Rarest First strategy should include randomization among at least several of the least common pieces, as having many clients all attempting to jump on the same "least common" piece would be counterproductive.” So, after calculating the rarest piece list, we shuffle some of the rarest entries.

* We wanted to make sure that if a peer's socket failed, we would keep monitoring the out-of-commision fd in case it attempted to reconnect. This is why we keep a dead_swarm list.  


## Module decomposition
### State maintenance modules
#### Bee
A class that keeps track of a single peer in the swarm. It maintains:
* The indices of the pieces that the peer has
* A queue of outstanding requests that the peer has made to our client
* The choke and interest relationship between the peer and our client (there are four statuses: (me | peer)(choked | interested))
* The last time our peer sent us a message (inactive peers are disconnected after 2 minutes)

#### Request
A class that keeps track of a single request that a peer has made to our client. Used as an element in the requests queue described in the above Bee class. 

#### PieceList
A class that keeps track of the pieces and blocks that our client wants to or has written to file. Pieces are uniform-length<sup>1</sup>. hash-verifiable fragments of the downloading file. Blocks are uniform-length<sup>2</sup>. subdivisions of pieces for which peers send out request messages.

A piece index is RESOLVED once all its blocks have been received and together hash-verified, and UNRESOLVED otherwise. 

A block index is REQUESTED if our client has sent out a request message for it to at least one peer. A block index is RECEIVED once our client has received a corresponding piece message from a peer. A block index is READY if it has not yet been received, and if our client has not made any outstanding request messages for it. 

<sup>1</sup> Piece length is determined by the metadata specified by the .torrent file. The last piece in a file may be shorter than the others. 

<sup>2</sup> Each client determines its own block length, although there may be size constraints (see the dispute at https://wiki.theory.org/BitTorrentSpecification#request:_.3Clen.3D0013.3E.3Cid.3D6.3E.3Cindex.3E.3Cbegin.3E.3Clength.3E). Peers are responsible, via the slightly-misleadingly-named piece message, for responding with the correctly-sized block. Our client requests blocks of 16000 bytes.

### Tracker messaging modules
#### get_info_from_tracker
Constructs requests for the different types of supported trackers (see "Feature overview") and sends those requests.

#### construct_http_requests
Auxiliary functions for get_info_from_tracker

#### send_receive_message
Decodes a tracker's HTTP response

### Peer messaging modules
#### construct_messages
Constructs messages to be sent to peers

#### handle_messages
Handles the receipt of peer messages. May send responses to peers if prompted (like when receiving a request), but does not contain logic for self-initiated messages (like when generating a request)

#### handshake
Handles intial handshake between peers and when new peers contact you it handles incoming data about the peer

#### download_strat
Calculates the next pieces to request using rarest first strategy according to piecelist.

### Driver module
#### driver
Interfaces all the other modules described in this section: 
* Communicates with tracker
* Creates a bee list with all the peers that connect correctly after handshake
* Creates a piecelist with corresponding length
* Requesting pieces from unchoked peers starting with rarest according to initial bitfields
* Periodically optimistic unchoke and unchoke top 4 peers to handle their requests
* Dispatch any incoming peers 

### Utility modules
#### send_receive_message
Handles basic looping on a TCP socket in order send and receive the expected number of bytes.

#### errors
Largely for handling tcp socket issues like a peer disconnecting without interrupting the overall download

# 3. Experiments: TODO
* Runs with varying max pending requests
* Runs where we randomize everytime or hold it
* Running multiple clients on one torrent
* Comparison to qbittorrent or transmission
* show how making the timeout too low on PieceList.REQUESTED can cause a bunch of duplicate requests/”received a piece we weren't expecting” messages → talk about how future work could make this timeout be be calculated and updated on the fly depending on how many of those messages we are receiving 

# 4. Problems encountered and addressed
* Our client is much slower than Transmission and qBitTorrent. A few things we attempted in our pursuit of speed include: 
	* Assembling pieces in RAM instead of writing blocks to disk immediately upon receipt.See (2) for further discussion. 
	* Sending requests immediately after receiving a piece. We noticed that our piece-processing loop took up the majority of the running time, so we thought that sending out requests right before entering this loop would increase parallelism. Peers could work on processing our new requests while we did the file I/O that was often necessary to process the pieces we just received. TODO: discuss effectiveness

* Piece and block indices needed to be checked to see if they were the last piece a file or block in a piece, as those lengths could be shorter than normal. 

* Our client does not work on a Ubuntu VM. The flabbergasting thing is, the VM CAN connect to peer sockets, but it never succeeds at doing the BitTorrent handshake with them. Running the client natively allows both to happen. Solution: Abandon the VM. Effectiveness: Frustratingly, very effective. 


# 5. Known issues

## Fatal bugs
* If many instances of our client try to download cosmos-laundromat.torrent, they all stall at 842 pieces (out of 843). If we stop testing and return a few hours later, we can download the entire file once more. Somehow, something in this download has the capacity to be overwhelmed. 

* Some online torrents don't send us back any peers.

## Performance bugs
* At seemingly random points in a download our client can face a significant reduction in speed before returning back to normal.

* For some of the torrent files where we receive a lot of peers, many of those sockets won’t open (is it possible that they are behind a firewall like us?) and for a few the connection gets reset after the handshake.

## Nonexistance bugs (we didn't implement the feature yet 🙁)
* We don't send out cancel messages once a request times out. 

* We don't send cancel messages during endgame. 

* We don’t attempt to hole-punch through our firewall to our peers. We can initiate a connection to peers advertised by the tracker, but anyone who is not on the machine running our client will fail to initiate a connection to us. 

# 6. Contributors and their contributions

cdavis73 - Calvin Davis
* HTTPS support
* general debugging and testing protocols

pmiller8 - Patrick Miller 
* Handshake protocol
* Top 4 (keeping score) + optimistic unchoking
* download strategy + rarest first
* Argument parser
* Documentation

smay1 - Sabine May
* Peer message handling
* Peer state tracking
* Local piece resolution
* Driver loop
* Documentation + package manifest

ydesilva - Yasadu De Silva
* Tracker communication + UDP support
* TCP message handling
* Download efficiency
* Multi-file output 

