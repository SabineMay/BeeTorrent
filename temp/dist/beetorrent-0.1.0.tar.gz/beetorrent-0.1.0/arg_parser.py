def arg_parse(argv):
    if (len(argv) == 3):
        if (argv[1] == '-f'):
            return (6881, argv[2])
        else:
            print('Invalid Arguments')
            exit()
    elif (len(argv) == 5):
        if (argv[1] == '-f' and argv[3] == '-p'):
            return (int(argv[4]), argv[2])
        elif (argv[1] == '-p' and argv[3] == '-f'):
            return (int(argv[2], argv[4]))
        else:
            print('Invalid Arguments')
            exit()
    else:
        print('Invalid Arguments')
        exit()